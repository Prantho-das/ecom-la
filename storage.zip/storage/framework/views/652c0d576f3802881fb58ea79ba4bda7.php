<footer class="bg-slate-900 text-slate-400">
  <div class="container px-4 py-10 mx-auto lg:py-24 md:py-16">
    <!-- Footer Links Grid -->
    <div class="grid grid-cols-1 gap-8 mb-4 md:grid-cols-2 lg:grid-cols-4">
      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="space-y-4">
          <h3 class="text-lg font-bold text-white"><?php echo e(Str::of($menu->name)->after('Footer ')->title()); ?></h3>
          <ul class="space-y-2">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $menu->links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><a href="<?php echo e($link->url); ?>" class="hover:text-white"><?php echo e($link->label); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
          </ul>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>


    <!-- Footer Bottom -->
    <div class="pt-4 text-sm text-center border-t border-slate-700 lg:pt-8">
      <p>DatoHall © <?php echo e(date('Y')); ?>. All Rights Reserved.</p>
    </div>
  </div>
</footer>
<?php /**PATH C:\laragon\www\ecom-la\resources\views/components/footer.blade.php ENDPATH**/ ?>