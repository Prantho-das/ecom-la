<section>
    <?php if (isset($component)) { $__componentOriginal20742eb2771d985bdc9eeee85f5ff6b5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal20742eb2771d985bdc9eeee85f5ff6b5 = $attributes; } ?>
<?php $component = App\View\Components\Hero::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Hero::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal20742eb2771d985bdc9eeee85f5ff6b5)): ?>
<?php $attributes = $__attributesOriginal20742eb2771d985bdc9eeee85f5ff6b5; ?>
<?php unset($__attributesOriginal20742eb2771d985bdc9eeee85f5ff6b5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal20742eb2771d985bdc9eeee85f5ff6b5)): ?>
<?php $component = $__componentOriginal20742eb2771d985bdc9eeee85f5ff6b5; ?>
<?php unset($__componentOriginal20742eb2771d985bdc9eeee85f5ff6b5); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalcabc30373012b73333ffad1027234353 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcabc30373012b73333ffad1027234353 = $attributes; } ?>
<?php $component = App\View\Components\About::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('about'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\About::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcabc30373012b73333ffad1027234353)): ?>
<?php $attributes = $__attributesOriginalcabc30373012b73333ffad1027234353; ?>
<?php unset($__attributesOriginalcabc30373012b73333ffad1027234353); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcabc30373012b73333ffad1027234353)): ?>
<?php $component = $__componentOriginalcabc30373012b73333ffad1027234353; ?>
<?php unset($__componentOriginalcabc30373012b73333ffad1027234353); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal0f70ef1089d864a486e62f6bd9b44873 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f70ef1089d864a486e62f6bd9b44873 = $attributes; } ?>
<?php $component = App\View\Components\Service::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Service::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f70ef1089d864a486e62f6bd9b44873)): ?>
<?php $attributes = $__attributesOriginal0f70ef1089d864a486e62f6bd9b44873; ?>
<?php unset($__attributesOriginal0f70ef1089d864a486e62f6bd9b44873); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f70ef1089d864a486e62f6bd9b44873)): ?>
<?php $component = $__componentOriginal0f70ef1089d864a486e62f6bd9b44873; ?>
<?php unset($__componentOriginal0f70ef1089d864a486e62f6bd9b44873); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal9d15eda6696f210c52e00365a972a145 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9d15eda6696f210c52e00365a972a145 = $attributes; } ?>
<?php $component = App\View\Components\WhyChooseUs::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('why-choose-us'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\WhyChooseUs::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9d15eda6696f210c52e00365a972a145)): ?>
<?php $attributes = $__attributesOriginal9d15eda6696f210c52e00365a972a145; ?>
<?php unset($__attributesOriginal9d15eda6696f210c52e00365a972a145); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9d15eda6696f210c52e00365a972a145)): ?>
<?php $component = $__componentOriginal9d15eda6696f210c52e00365a972a145; ?>
<?php unset($__componentOriginal9d15eda6696f210c52e00365a972a145); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal4d5d2495d4f761c086c82a2e66994c4c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4d5d2495d4f761c086c82a2e66994c4c = $attributes; } ?>
<?php $component = App\View\Components\Features::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('features'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Features::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4d5d2495d4f761c086c82a2e66994c4c)): ?>
<?php $attributes = $__attributesOriginal4d5d2495d4f761c086c82a2e66994c4c; ?>
<?php unset($__attributesOriginal4d5d2495d4f761c086c82a2e66994c4c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d5d2495d4f761c086c82a2e66994c4c)): ?>
<?php $component = $__componentOriginal4d5d2495d4f761c086c82a2e66994c4c; ?>
<?php unset($__componentOriginal4d5d2495d4f761c086c82a2e66994c4c); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal6e3b632f3d8adb20669a2a5982e4d991 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6e3b632f3d8adb20669a2a5982e4d991 = $attributes; } ?>
<?php $component = App\View\Components\Products::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('products'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Products::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6e3b632f3d8adb20669a2a5982e4d991)): ?>
<?php $attributes = $__attributesOriginal6e3b632f3d8adb20669a2a5982e4d991; ?>
<?php unset($__attributesOriginal6e3b632f3d8adb20669a2a5982e4d991); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6e3b632f3d8adb20669a2a5982e4d991)): ?>
<?php $component = $__componentOriginal6e3b632f3d8adb20669a2a5982e4d991; ?>
<?php unset($__componentOriginal6e3b632f3d8adb20669a2a5982e4d991); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal9e957fa9376c229c22c28ec4e9b6f864 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864 = $attributes; } ?>
<?php $component = App\View\Components\Blog::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('blog'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Blog::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864)): ?>
<?php $attributes = $__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864; ?>
<?php unset($__attributesOriginal9e957fa9376c229c22c28ec4e9b6f864); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9e957fa9376c229c22c28ec4e9b6f864)): ?>
<?php $component = $__componentOriginal9e957fa9376c229c22c28ec4e9b6f864; ?>
<?php unset($__componentOriginal9e957fa9376c229c22c28ec4e9b6f864); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginala3c1d951ce64ffbbe4289a42ad7c6d3d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala3c1d951ce64ffbbe4289a42ad7c6d3d = $attributes; } ?>
<?php $component = App\View\Components\Cta::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('cta'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Cta::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala3c1d951ce64ffbbe4289a42ad7c6d3d)): ?>
<?php $attributes = $__attributesOriginala3c1d951ce64ffbbe4289a42ad7c6d3d; ?>
<?php unset($__attributesOriginala3c1d951ce64ffbbe4289a42ad7c6d3d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala3c1d951ce64ffbbe4289a42ad7c6d3d)): ?>
<?php $component = $__componentOriginala3c1d951ce64ffbbe4289a42ad7c6d3d; ?>
<?php unset($__componentOriginala3c1d951ce64ffbbe4289a42ad7c6d3d); ?>
<?php endif; ?>
</section>
<?php /**PATH C:\laragon\www\ecom-la\resources\views/livewire/frontend/home.blade.php ENDPATH**/ ?>