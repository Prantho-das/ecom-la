<dialog x-data="{ productSlug: '' }" @open-product-modal.window="productSlug = $event.detail.slug" id="my_modal_3"
    class="modal rounden-0">
    <div class="modal-box p-0 w-11/12 max-w-6xl h-[90vh]">
        <form method="dialog">
            <button class="btn btn-sm btn-circle btn-ghost absolute right-2 top-2">✕</button>
        </form>
        <?php
            $firstContinent = null;
            $continents = cache()->rememberForever(
                'continents',
                fn() => DB::table('continents')->orderBy('name')->get(),
            );
            $firstContinent = $continents->first()->id;
        ?>


        <div class="flex h-full" x-data="{ activeTab: '<?php echo e($firstContinent); ?>' }">

            <!-- Vertical Tabs Sidebar -->
            <div class="lg:w-64 md:w-40 bg-white border-r border-gray-200">
                <div class="px-4 py-3 border-b border-gray-200 mb-0 bg-white text-center justify-center">
                    <h2 class="text-2xl font-semibold text-center">
                        Continent
                    </h2>
                </div>
                <div class="tabs tabs-boxed flex-col h-full ">

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $continents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $conti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="tab tab-lg text-base font-medium h-12 "
                            :class="{ 'tab-active bg-green-600 text-white font-semibold': activeTab === '<?php echo e($conti->id); ?>' }"
                            @click="activeTab = '<?php echo e($conti->id); ?>'">
                            <?php echo e($conti->name); ?>

                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>

            <!-- Tab Content Area - NOW WITH bg-gray-100 -->
            <div class="flex-1  overflow-y-auto bg-white">

                <!-- Asia -->
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $continents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php

                        $countries = \DB::table('countries')->where('continent_id', $conti->id)->orderBy('name')->get();
                    ?>
                    <div x-show="activeTab === '<?php echo e($conti->id); ?>'" class="space-y-6">
                        <div class="px-4 py-3 border-b border-gray-200 mb-0 bg-white">
                            <h2 class="text-2xl font-semibold flex items-center gap-3">
                                Asia <span class="badge badge-lg text-gray-400 !text-sm">48 Countries</span>
                            </h2>
                        </div>
                        <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2 p-4 bg-white">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a
                                    @click.prevent="window.location.href = '/details/' + productSlug + '?country=<?php echo e($country->code); ?>'">
                                    <div class="text-start cursor-pointer text-gray-800 hover:text-green-600">
                                        <h3 class="font-base text-sm"><?php echo e($country->name); ?></h3>
                                    </div>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                        <div class="text-center">
                            <button class="btn btn-sm">Load More</button>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            </div>
        </div>
    </div>
</dialog>
<?php /**PATH C:\laragon\www\ecom-la\resources\views/components/country-modal.blade.php ENDPATH**/ ?>