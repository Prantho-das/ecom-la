<section class="py-10 bg-white lg:py-24 md:py-16">
    <div class="container px-4 mx-auto">
        <div class="flex flex-col lg:flex-row gap-12 justify-center items-center w-full">

            <!-- Left Content -->
            <div class="pr-0 lg:pr-12 basis-2/3">
                <p class="mb-2 font-semibold tracking-wider text-lime-600">
                    <?php echo e($subtitle); ?>

                </p>
                <h2 class="mb-6 text-4xl font-bold md:text-5xl text-slate-900">
                    <?php echo e($title); ?>

                </h2>
                
                <p class="mb-6 text-slate-600">
                    <?php echo $description; ?>

                </p>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($listItems)): ?>
                <ul class="mb-8 space-y-3 text-slate-700">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $listItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="flex items-center">
                        <span><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6  text-blue-600">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                          </svg></span>
                        <span class="ml-3"><?php echo e($item['item']); ?></span>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </ul>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <a href="<?php echo e($buttonLink); ?>"
                    class="px-8 py-3 font-bold text-white transition-colors rounded-full bg-slate-900 hover:bg-slate-800">
                    <?php echo e($buttonText); ?>

                </a>
            </div>

            <!-- Right Content -->
            <div class="relative mx-auto basis-1/3">
                <img src="<?php echo e($image ? asset('storage/' . $image) : 'https://picsum.photos/seed/dam/500/600'); ?>"
                    alt="<?php echo e($title); ?>" class="h-auto shadow-xl rounded-2xl aspect-[5/6] w-full object-cover " />

                <!-- Stats Cards -->
                <div class="absolute flex flex-col w-full gap-4 bottom-8 sm:-left-12 left-8 lg:flex-col xl:flex-row">
                    <div class="bg-[#a4cc1c] text-white p-8 rounded-2xl shadow-lg w-64">
                        <p class="font-semibold"><?php echo e($stat1Title); ?></p>
                        <p class="text-4xl font-bold md:text-6xl"><?php echo e($stat1Value); ?></p>
                        <p class="mt-2 text-sm"><?php echo e($stat1Description); ?></p>
                    </div>

                    <div class="bg-[#002134] text-white p-8 rounded-2xl shadow-lg w-64">
                        <p class="font-semibold"><?php echo e($stat2Title); ?></p>
                        <p class="text-4xl font-bold md:text-6xl"><?php echo e($stat2Value); ?></p>
                        <p class="mt-2 text-sm"><?php echo e($stat2Description); ?></p>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>
<?php /**PATH C:\laragon\www\ecom-la\resources\views/components/about.blade.php ENDPATH**/ ?>