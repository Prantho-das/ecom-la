<section class="lg:py-24 md:py-16 py-10 bg-white">
  <div class="container lg:max-w-[1780px] mx-auto px-4  ">
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-12">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $featuresList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="flex items-start space-x-4">

                <div class="text-orange-500 mt-1 text-5xl"><?php echo $feature['icon']; ?></div>
                <div>
                    <h3 class="font-bold text-xl mb-2 text-slate-900"><?php echo e($feature['title']); ?></h3>
                    <p class="text-slate-600">
                        <?php echo e($feature['description']); ?>

                    </p>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-gray-500 col-span-full text-center">No features available.</p>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
  </div>
</section>
<?php /**PATH C:\laragon\www\ecom-la\resources\views/components/features.blade.php ENDPATH**/ ?>