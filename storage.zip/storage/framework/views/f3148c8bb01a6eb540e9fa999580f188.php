<section class="py-10 lg:py-24 md:py-16 bg-slate-50 <?php echo e(empty($products) ? 'hidden' : ''); ?>">
    <div class="lg:max-w-[1780px] mx-auto px-4  ">

        <!-- Header -->
        <div class="flex items-center justify-between mb-12">
            <h2 class="text-4xl font-bold md:text-5xl text-slate-900">New Products</h2>
            <a href="<?php echo e(route('category')); ?>"
                class="flex items-center space-x-2 text-slate-600 hover:text-[#27ad4c] font-medium transition duration-300">
                <div class="flex items-center justify-center w-8 h-8 border rounded-full border-slate-400 p-1">
                    <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-arrow-up-right'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                </div>
                <span>View All Product</span>
            </a>
        </div>

        <!-- Products Grid -->
        <div class="grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5">

            <!-- Product 1 -->
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a


                       @click="
            $dispatch('open-product-modal', <?php echo e(json_encode(['slug' => $product->slug])); ?>);
            my_modal_3.showModal();
        "


        >
                    <div
                        class="bg-white rounded-lg shadow-md p-4 text-center group transition-all duration-300 hover:shadow-xl hover:-translate-y-1 hover:scale-[1.02]">
                        <div
                            class="relative flex items-center justify-center h-56 mb-4 rounded-lg overflow-hidden border border-gray-100">
                            <img src="<?php echo e($product->thumbnail ? asset('storage/' . $product->thumbnail) : 'https://placehold.co/600x400?text=' . $product->name); ?>"
                                alt=<?php echo e($product->name); ?> class="object-cover max-w-full max-h-full aspect-square">
                        </div>
                        <h3 class="font-bold text-slate-800 group-hover:text-[#27ad4c]"><?php echo e($product->name); ?></h3>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <!-- You can open the modal using ID.showModal() method -->
         <?php if (isset($component)) { $__componentOriginal317f9f7a9a5fed9c52fc6773485e1d1e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal317f9f7a9a5fed9c52fc6773485e1d1e = $attributes; } ?>
<?php $component = App\View\Components\CountryModal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('country-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\CountryModal::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal317f9f7a9a5fed9c52fc6773485e1d1e)): ?>
<?php $attributes = $__attributesOriginal317f9f7a9a5fed9c52fc6773485e1d1e; ?>
<?php unset($__attributesOriginal317f9f7a9a5fed9c52fc6773485e1d1e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal317f9f7a9a5fed9c52fc6773485e1d1e)): ?>
<?php $component = $__componentOriginal317f9f7a9a5fed9c52fc6773485e1d1e; ?>
<?php unset($__componentOriginal317f9f7a9a5fed9c52fc6773485e1d1e); ?>
<?php endif; ?>


        </div>
    </div>
</section>
<?php /**PATH C:\laragon\www\ecom-la\resources\views/components/products.blade.php ENDPATH**/ ?>