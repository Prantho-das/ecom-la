<section class="bg-white">
    











    <div class="max-w-screen-xl px-4 mx-auto sm:px-6 lg:px-8">
        <!-- Breadcrumb -->
        <nav class="py-4 text-sm text-gray-500">
            <a href="/" class="hover:underline">Home</a> &gt;
            <a href="/products" class="hover:underline">Products</a> &gt;
            <span><?php echo e($product->name); ?></span>
        </nav>

        <!-- Product Hero -->
        <section class="grid grid-cols-1 gap-8 py-8 lg:grid-cols-2" wire:ignore>
            <!-- Left Column - Image Gallery -->
            

            <div>
                <!-- Main Gallery -->
                <div class="w-full mb-4 border border-gray-200 rounded-lg swiper mySwiper2">
                    <div class="swiper-wrapper">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="swiper-slide">
                                <img src="<?php echo e(asset('storage/' . $image)); ?>"
                                    class="object-contain w-full h-auto md:h-full max-h-screen aspect-square object-cover"
                                    alt="Server Rack">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                    <div class="swiper-button-next text-gray-600"></div>
                    <div class="swiper-button-prev text-gray-600"></div>
                </div>

                <!-- Thumbnails -->
                <div class="mt-4 swiper mySwiper">
                    <div class="swiper-wrapper">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div
                                class="w-24 h-24 overflow-hidden border-2 border-gray-300 hover:border-green-600 rounded-lg cursor-pointer swiper-slide">
                                <img src="<?php echo e(asset('storage/' . $image)); ?>"
                                    class="object-cover w-full h-full aspect-square" alt="Thumbnail">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Right Column - Details -->
            <div>
                <div class="w-10 mb-2">
                    <img src="<?php echo e($product->brand && $product->brand->logo_path ? asset('storage/' . $product->brand->logo_path) : 'https://placehold.co/600x400?text=' . $product->name); ?>"
                        alt="<?php echo e($product->brand?->name); ?>">
                </div>

                <h1 class="mb-2 text-3xl font-light text-black"><?php echo e($product->name); ?></h1>
                <p class="mb-2 text-sm text-gray-500 ">SKU: <?php echo e($product->sku); ?></p>
                <hr class="my-6">
                <button
                    class="text-sm font-semibold mb-4 text-green-600 rounded hover:text-green-800 transition drop-shadow-blue-300 flex items-center gap-1">
                    <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-star'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-5 h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?> Add to My Quotation</button>



                <ul class="mb-6 space-y-2 text-gray-500 text-base">
                    <li class="flex items-start ">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                            stroke="currentColor" class="size-4 text-green-600 mr-2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                        </svg>
                        2 pure sine wave AC
                        outlets
                    </li>
                    <li class="flex items-start "><svg xmlns="http://www.w3.org/2000/svg" fill="none"
                            viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                            class="size-4 text-green-600 mr-2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                        </svg>
                        3 USB-A and 1 USB-C
                        PD60W</li>
                    <li class="flex items-start "><svg xmlns="http://www.w3.org/2000/svg" fill="none"
                            viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                            class="size-4 text-green-600 mr-2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />
                        </svg>
                        Recharge via wall,
                        solar, and car</li>
                </ul>

                

                <div class="space-y-3">
                    <a href="/reseller-partner"
                        class="flex items-center text-sm font-semibold text-green-600 hover:text-green-800">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                            stroke="currentColor" class="size-4 text-green-600 mr-2">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M15 10.5a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1 1 15 0Z" />
                        </svg>
                        Find a reseller
                    </a>
                    <a href="mailto:sales@example.com"
                        class="flex items-center text-sm font-semibold text-green-600 hover:text-green-800">

                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                            stroke-width="1.5" stroke="currentColor" class="size-4 text-green-600 mr-2">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M21.75 6.75v10.5a2.25 2.25 0 0 1-2.25 2.25h-15a2.25 2.25 0 0 1-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0 0 19.5 4.5h-15a2.25 2.25 0 0 0-2.25 2.25m19.5 0v.243a2.25 2.25 0 0 1-1.07 1.916l-7.5 4.615a2.25 2.25 0 0 1-2.36 0L3.32 8.91a2.25 2.25 0 0 1-1.07-1.916V6.75" />
                        </svg>
                        Contact Sales
                    </a>
                </div>
            </div>
        </section>

        <!-- Main Documents -->
        <section class="py-8">
            <h2 class="mb-6 text-2xl font-light">Main Documents</h2>
            <div class="p-6 border border-gray-200 rounded-lg">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($product->pdf_files)): ?>
                    <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $product->pdf_files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pdf_file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(asset('storage/' . $pdf_file)); ?>" target="_blank"
                                class="flex items-center text-gray-700 hover:text-green-600 group">
                                <span class="mr-2 ">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                        stroke-width="1.5" stroke="currentColor" class="size-5 text-red-700">
                                        <path stroke-linecap="round" stroke-linejoin="round"
                                            d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z" />
                                    </svg>

                                </span> <?php echo e(basename($pdf_file)); ?>

                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                <?php else: ?>
                    <p class="text-gray-500">No main documents available.</p>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </section>

        <!-- Description -->
        <section class="py-8">
            <h2 class="mb-4 text-2xl font-light">Description</h2>
            <div x-data="{ expanded: false }" class="relative">
                <div x-show="expanded" class="prose max-w-none">
                    <?php echo $product->description; ?>

                </div>
                <div x-show="!expanded" class="prose max-w-none line-clamp-3">
                    <?php echo $product->description; ?>

                </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(strlen(strip_tags($product->description)) > 200): ?>
                    
                    <button x-on:click="expanded = !expanded"
                        class="flex items-center mt-2 text-sm font-semibold text-green-600 hover:text-green-800">
                        <span x-show="!expanded">Read more</span>
                        <span x-show="expanded">Read less</span>
                    </button>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </section>

        <!-- Specifications -->
        <section class="py-8">
            <h2 class="mb-4 text-2xl font-light ">Specifications</h2>
            <div class="p-6 space-y-4 border border-gray-200 rounded-lg">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $product->custom_sections ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div>
                        <div class="bg-gray-200 px-3 py-1">
                            <h3 class="text-base font-semibold text-gray-800 "><?php echo e($section['title']); ?></h3>
                        </div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $section['fields'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="grid grid-cols-1 gap-2 px-3 py-1 border-b border-gray-100 md:grid-cols-3">
                                <dt class="font-semibold text-gray-600"><?php echo e($field['key']); ?></dt>
                                <dd class="text-gray-800 md:col-span-2"><?php echo e($field['value']); ?></dd>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-gray-500">No specifications available.</p>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </section>

        <!-- Gallery -->
        <section class="py-8">
            <h2 class="mb-4 text-2xl font-light">Gallery</h2>
            <div class="grid grid-cols-2 gap-4 md:grid-cols-3">
                
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="image-a.jpeg" data-fancybox="gallery" data-caption="Gallery image">
                        <img src="<?php echo e(asset('storage/' . $image)); ?>"
                            class="object-cover w-full h-full aspect-square rounded-lg" alt="Gallery Image">
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </section>

        <!-- FAQ -->
        <section class="py-8">
            <h2 class="mb-4 text-2xl font-light">FAQ</h2>

            <?php
                $faqSection = collect($product->custom_sections ?? [])->firstWhere('title', 'FAQ');
            ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($faqSection && !empty($faqSection['fields'])): ?>
                <div class="space-y-3">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $faqSection['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $faqItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="collapse bg-base-100 border border-base-300 rounded-lg">
                            <input type="radio" name="faq-accordion" <?php echo e($index === 0 ? 'checked' : ''); ?> />
                            <div class="collapse-title font-semibold">
                                <?php echo e($faqItem['key']); ?>

                            </div>
                            <div class="collapse-content text-gray-600 text-sm">
                                <?php echo e($faqItem['value']); ?>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            <?php else: ?>
                <p class="text-gray-500">No FAQs available.</p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </section>


        <!-- Related Products Swiper -->
        <section class="py-8" wire:ignore>
            <h2 class="mb-4 text-2xl font-light">Related Products</h2>
            <div class="swiper relatedSwiper">
                <div class="swiper-wrapper">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="swiper-slide">
                            <div
                                class="flex flex-col items-center h-full p-6 text-center bg-white border border-gray-200 rounded-lg">
                                <img src="<?php echo e($relatedProduct->logo_path ? asset('storage/' . $relatedProduct->thumbnail) : 'https://placehold.co/600x400?text=' . $relatedProduct->name); ?>"
                                    alt="<?php echo e($relatedProduct->name); ?>" class="object-contain w-40 h-40 my-4" />
                                <p class="mb-2 text-sm text-gray-500">AR3003</p>
                                <h3 class="text-base font-medium text-gray-800"><?php echo e($relatedProduct->name); ?></h3>
                                <a href="<?php echo e(route('details', $relatedProduct->slug)); ?>"
                                    class="inline-block w-full px-4 py-2 mt-6 border border-gray-300 rounded-md hover:bg-gray-100">
                                    View Details
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                </div>
                <!-- Optional navigation -->
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
            </div>
        </section>

    </div>
</section>
<?php $__env->startPush('scripts'); ?>
    <script>
        function initializeSwipers() {
            console.log("Swiper Init");

            // destroy existing swiper
            document.querySelectorAll('.swiper').forEach(swiperEl => {
                if (swiperEl.swiper) {
                    swiperEl.swiper.destroy(true, true);
                }
            });

            // Thumbs
            const swiperThumbs = new Swiper(".mySwiper", {
                spaceBetween: 10,
                slidesPerView: 3,
                freeMode: true,
                watchSlidesProgress: true,
                touchStartPreventDefault: false
            });

            // Main Slider
            const swiperMain = new Swiper(".mySwiper2", {
                spaceBetween: 10,
                touchStartPreventDefault: false,
                navigation: {
                    nextEl: ".mySwiper2 .swiper-button-next",
                    prevEl: ".mySwiper2 .swiper-button-prev",
                },
                thumbs: {
                    swiper: swiperThumbs
                },
            });

            // Related slider
            const relatedSwiper = new Swiper(".relatedSwiper", {
                slidesPerView: 2,
                spaceBetween: 16,
                touchStartPreventDefault: false,
                navigation: {
                    nextEl: ".relatedSwiper .swiper-button-next",
                    prevEl: ".relatedSwiper .swiper-button-prev",
                },
                breakpoints: {
                    640: {
                        slidesPerView: 3
                    },
                    1024: {
                        slidesPerView: 4
                    }
                }
            });
        }

        document.addEventListener("DOMContentLoaded", initializeSwipers);
        document.addEventListener("livewire:navigated", initializeSwipers);
        document.querySelectorAll('.faq-question').forEach(q => {
            q.addEventListener('click', () => {
                const answer = q.nextElementSibling;
                answer.classList.toggle('hidden');
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\ecom-la\resources\views/livewire/frontend/details.blade.php ENDPATH**/ ?>