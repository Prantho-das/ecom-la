<header>
    <!-- Top Bar -->
    <div class="bg-[#27ad4c] text-white text-sm">
        <div class="container lg:max-w-[1780px] mx-auto px-4">
            <div class="flex items-center justify-between py-2">
                <div class="flex items-center space-x-4">
                    <div class="flex items-center space-x-1">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                            stroke="currentColor" class="size-5">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M12 6v6h4.5m4.5 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                        </svg>

                        <span>Mon – Fri 8:00 – 18:00 / Sunday 8:00 – 14:00</span>
                    </div>

                    <div class="items-center hidden space-x-1 md:flex">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                            stroke="currentColor" class="size-6">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M21.75 6.75v10.5a2.25 2.25 0 0 1-2.25 2.25h-15a2.25 2.25 0 0 1-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0 0 19.5 4.5h-15a2.25 2.25 0 0 0-2.25 2.25m19.5 0v.243a2.25 2.25 0 0 1-1.07 1.916l-7.5 4.615a2.25 2.25 0 0 1-2.36 0L3.32 8.91a2.25 2.25 0 0 1-1.07-1.916V6.75" />
                        </svg>

                        <a href="mailto:info@" class="hover:underline">info@datohall.com</a>
                    </div>
                </div>

                

                <?php if (isset($component)) { $__componentOriginal66d15c24934d2f8d7fcfc4f12169c2fa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal66d15c24934d2f8d7fcfc4f12169c2fa = $attributes; } ?>
<?php $component = App\View\Components\SocialMedia::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('social-media'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SocialMedia::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal66d15c24934d2f8d7fcfc4f12169c2fa)): ?>
<?php $attributes = $__attributesOriginal66d15c24934d2f8d7fcfc4f12169c2fa; ?>
<?php unset($__attributesOriginal66d15c24934d2f8d7fcfc4f12169c2fa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal66d15c24934d2f8d7fcfc4f12169c2fa)): ?>
<?php $component = $__componentOriginal66d15c24934d2f8d7fcfc4f12169c2fa; ?>
<?php unset($__componentOriginal66d15c24934d2f8d7fcfc4f12169c2fa); ?>
<?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Main Navigation -->
    <div class="sticky top-0 z-50 bg-white shadow-sm lg:shadow-none">
        <div class="container lg:max-w-[1780px] mx-auto px-4">
            <div class="flex items-center justify-between py-3 md:py-6">

                <!-- Logo -->
                <div class="lg:w-[150px] md:w-[150px] w-[120px]">
                    <a href="<?php echo e(route('home')); ?>" wire:navigate>
                        <?php
                            $site_logo = getSetting('logo');
                        ?>
                        <img src="<?php echo e($site_logo ? asset('storage/' . $site_logo) : asset('assets/images/logo.svg')); ?>"
                            alt="Logo" class="h-[40px]" />
                    </a>
                </div>

                <!-- Search Box -->
                <div class="relative hidden w-5/10 sm:block">
                    <form action="<?php echo e(route('category')); ?>">


                        <input type="text" placeholder="Search" name="search"
                            class="border border-gray-400 py-1.5 px-3 w-full focus:outline-none focus:ring-1 focus:ring-[#27ad4c]" />
                        <button class="absolute right-0 top-0 h-full px-2 text-white bg-[#27ad4c]">
                            <!-- SearchIcon -->
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="size-6">
                                <path stroke-linecap="round" stroke-linejoin="round"
                                    d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" />
                            </svg>

                        </button>
                    </form>
                </div>

                <!-- Desktop Links -->
                <div class="items-center hidden space-x-4 lg:flex">
                    <a href="#" class="font-medium text-slate-700 hover:text-[#27ad4c]">Login</a>
                    <a href="#"
                        class="bg-[#27ad4c] text-white font-bold py-2 px-4 rounded-md hover:bg-[#27ad4c] transition-colors">
                        Get a Free Quotation
                    </a>
                </div>

                <!-- Mobile Menu Button -->
                <div class="lg:hidden">
                    <button class="text-[#27ad4c]">
                        <!-- MenuIcon -->
                    </button>
                </div>
            </div>

            <!-- Desktop Navigation -->
            <nav class="items-center hidden space-x-6 font-semibold text-black lg:flex">
                <a href="<?php echo e(route('home')); ?>" wire:navigate
                    class="pb-2 <?php echo e(request()->routeIs('home') ? 'text-[#27ad4c] border-b-2 border-[#27ad4c]' : 'hover:text-[#27ad4c]'); ?>">
                    Home
                </a>

                <a href="<?php echo e(route('category')); ?>" wire:navigate class="pb-2 hover:text-[#27ad4c]">
                    Products
                </a>

                <a href="<?php echo e(route('reseller.partner')); ?>" wire:navigate class="pb-2 hover:text-[#27ad4c]">
                    Reseller
                </a>
                <a href="<?php echo e(route('contact')); ?>" wire:navigate class="pb-2 hover:text-[#27ad4c]">
                    Contact
                </a>
                

                
            </nav>

            <!-- Mobile Navigation -->
            <div class="hidden px-4 py-4 bg-white shadow-lg lg:hidden">

                <div class="relative w-full mb-4 sm:hidden">
                    <input type="text" placeholder="Search"
                        class="border border-gray-400 py-1.5 px-3 w-full focus:outline-none focus:ring-1 focus:ring-[#27ad4c]" />
                    <button class="absolute right-0 top-0 h-full px-2 text-white bg-[#27ad4c]">
                        <!-- SearchIcon -->
                    </button>
                </div>

                <nav class="flex flex-col space-y-4 font-medium text-slate-700">

                    <a href="<?php echo e(route('home')); ?>" wire:navigate class="pb-2 hover:text-[#27ad4c]">
                        Home
                    </a>

                    <a href="<?php echo e(route('category')); ?>" wire:navigate class="pb-2 hover:text-[#27ad4c]">
                        Products
                    </a>

                    <a href="<?php echo e(route('reseller.partner')); ?>" wire:navigate class="pb-2 hover:text-[#27ad4c]">
                        Reseller
                    </a>

                    <a href="#" class="pb-2 hover:text-[#27ad4c]">Software</a>
                    <a href="#" class="pb-2 hover:text-[#27ad4c]">Services</a>
                    <a href="#" class="pb-2 hover:text-[#27ad4c]">Solutions</a>
                    <a href="#" class="pb-2 hover:text-[#27ad4c]">Homeowner</a>
                    <a href="#" class="pb-2 hover:text-[#27ad4c]">Support</a>
                    <a href="#" class="pb-2 hover:text-[#27ad4c]">Company</a>

                    <div class="flex flex-col pt-4 space-y-4">
                        <a href="#" class="font-medium text-slate-700 hover:text-[#27ad4c]">Login</a>
                        <a href="#"
                            class="bg-[#27ad4c] text-white text-center font-bold py-2 px-4 rounded-md hover:bg-[#27ad4c]">
                            Get a Free Quotation
                        </a>
                    </div>

                </nav>
            </div>

        </div>
    </div>
</header>
<?php /**PATH C:\laragon\www\ecom-la\resources\views/components/header.blade.php ENDPATH**/ ?>